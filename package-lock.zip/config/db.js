// const mongoose = require('mongoose');

// const connection = mongoose.connect(process.env.DATABASE,{
//     useNewUrlParser:true,
//     useCreateIndex:true,
//     useUnifiedTopology:true,
//     useFindAndModify:false
// }).then(() => {
//     console.log(`Database Connection successful`);
// }).catch(err => {console.log(`Database is not connected`)})


const mongoose = require('mongoose');
const DB =process.env.DATABASE;
mongoose.connect(DB,{
    useNewUrlParser:true,
    useUnifiedTopology:true
 }).then(()=>{
    console.log(`connection sucessful`);
    
 }).catch((err)=>console.log(`no connection ${err}`)
 );