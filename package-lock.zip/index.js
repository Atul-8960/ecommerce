const express = require('express');
const morgan = require('morgan');
const cors = require('cors');
require('dotenv').config({
    path:'./config/config.env',
})
const PORT = process.env.PORT;

//mongo db conection


const app = express();

app.use(morgan('dev'));
app.use(cors());
app.use(express.json());

app.use('/api/users',require('./routers/router'));


app.listen(PORT, (req, res) => {
    console.log(`The server is listening on ${PORT}`)
})