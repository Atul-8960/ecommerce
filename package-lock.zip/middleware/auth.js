const jwt = require('jsonwebtoken');

module.exports = async (req, res, next) => {
   try{
    const token = await req.headers.get('token');

    if(!token){
        return res.status(422).json({message:"token not found"})
    }
     const data = await jwt.decode(token,process.env.SECRET_KEY);
     console.log(data);
     res.json(data);
   }
   catch(err){
       res.status(422).json({message: err.message});
   }
}