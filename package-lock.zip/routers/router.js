const express = require('express');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');
const route = express.Router();
require('../config/db')
//check validation for requests

const gravatar = require('gravatar');
const {check} = require('express-validator');
const auth = require('../middleware/auth');

require('../models/Client');


route.get('/',auth,(req, res) => {
    console.log(`hello World`);
    res.send("hello world");
})

//register clients api

route.post('/register', async (req, res) => {
    const {name,email,password} = req.body;
    try{
     const userExists = await Client.findOne({email: email});
     if(userExists){
         return res.status(400).json({msg:"user already exists"});
     }
     const avatar = gravatar.url(email,{
         s:"200", 
         r:"pg",
         d:"mm"
     })
     const salt = await bcrypt.genSalt(10);
     this.password = await bcrypt.hash(password,salt);
     const client = new Client({name,email,avatar,password});
     await client.save();

     //payload is used to generate token 
     const payload = {
         client:{
             id:client.id,
         }
     }
      
     jwt.sign(payload,process.env.SECRET_KEY,{
         expiresIn:360000
     },(err,token) => {
         if(err){
             throw err;
         }
         else{
             res.json({token:token});
         }
     })

    }
    catch(err){
        console.log(err);
    }
}
)

//login api

route.post('/login',[
    check('email','please enter a valid email').isEmail(),
    check('password','please enter a valid password').exists()
],async(req, res) => {
    const {email,password} = req.body;
    if(!email || !password) {
        return res.status(404).json({message:"please fill the details"})
    }

    try{
        const user = await Client.findOne({email});
        if(!user){
            return res.status(404).json({error : "email not found"});
        }
        const isMatch = await bcrypt.compare(password,user.password)
        //my alternative method
        const salt = await bcrypt.genSalt(10);
        this.password = await bcrypt.hash(password,salt);
        
        // if(!isMatch){
        //     return res.status(422).json({error : "password not matched"})
        // }
        if(password != user.password){
            return res.status(404).json({error : "password not matched"})
        }

        const payload = {
            user:{
                id:user.id
            }
        }

        jwt.sign(
            payload,
            process.env.SECRET_KEY,{
                expiresIn: 360000
            },(err,token) => {
                if(err) throw err;
                res.json({token});
            }
        )


    }
    catch(err){
        res.json({error:err});
        console.log(err);
    }
})

//getting all users 

route.get('/all',async (req, res) => {
    try{

        const data = await Client.find();
        if(!data){
            return res.status(404).json({error:"no data found"})
        }
        res.json(data);

    }
    catch (err){
        console.log(err);
        res.json({error:err});
    }
})


route.use((req,res) => {
    res.status(404).json({message:"page 404 error !!not found"});

})

module.exports = route